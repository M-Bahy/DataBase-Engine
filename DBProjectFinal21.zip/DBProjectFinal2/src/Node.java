package src;
public interface Node {

    Object getMax();

    Object getMin();

}
