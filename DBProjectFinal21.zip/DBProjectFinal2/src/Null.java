package src;
import java.io.Serializable;

public class Null implements Serializable {

	@Override
	public String toString() {
		return "Null";
	}
	
	




	

}
